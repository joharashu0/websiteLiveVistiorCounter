<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live vistior Count</title>
    <style>
    <style type="text/css">#online-visitors-list {
        background-color: white;
        text-align: center;
        font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
        font-weight: 300;
        font-size: 15px;
        color: #8dc0e3;
    }

    #online-visitors-list a {
        text-decoration: none;
        color: #8dc066;
        padding-left: 5px;
    }

    #online-visitors-list b {
        font-size: 30px;
        color: #8db0e3;
    }
    </style>

    </style>
</head>
<h1>Thankyou For Watching this video</h1>
<p>I will give my whole source code in video description</p>
<p>thankyou</p>

<body>

    <script src="ovc/counter.js"></script>
</body>

</html>